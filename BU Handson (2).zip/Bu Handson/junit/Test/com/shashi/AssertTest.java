package com.shashi;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertTest {

	@Test
	public void test() {
		//assertEquals(1, 1);
		boolean condn = true;
		assertEquals(true, condn);
		assertTrue(condn);
		assertFalse(condn);
		//assertArrayEquals(expecteds, actuals);
	}

}
