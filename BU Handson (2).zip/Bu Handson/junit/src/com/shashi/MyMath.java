package com.shashi;

public class MyMath {

	static int sum(int[] numbers){
		int sum = 0;
		for (int i: numbers){
			sum +=i;
		}
		return sum ;
	}
}
